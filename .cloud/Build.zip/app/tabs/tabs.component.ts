import { Component, OnInit } from "@angular/core";

@Component({
    selector: "TabsComponent",
    moduleId: module.id,
    templateUrl: "./tabs.component.html",
    styleUrls:['./tabs.component.css']
})
export class TabsComponent implements OnInit {
    constructor() {

    }

    ngOnInit(): void {

    }
}
