import { Component, OnInit, ViewChild } from "@angular/core";

@Component({
    selector: "Settings",
    moduleId: module.id,
    templateUrl: "./settings.component.html",
})
export class SettingsComponent implements OnInit {
    constructor() {

    }

    ngOnInit(): void {

    }
}
