import { Component, OnInit, ViewChild } from "@angular/core";

@Component({
    selector: "Featured",
    moduleId: module.id,
    templateUrl: "./featured.component.html",
})
export class FeaturedComponent implements OnInit {
    constructor() {

    }

    ngOnInit(): void {

    }
}
